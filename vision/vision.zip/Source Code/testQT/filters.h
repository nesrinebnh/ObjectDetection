#ifndef FILTERS_H    // To make sure you don't declare the function more than once by including the header multiple times.
#define FILTERS_H

#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/opencv.hpp>

using namespace cv;
using namespace std;

void medianFilter(Mat src, Mat dst, int voisinage);

#endif