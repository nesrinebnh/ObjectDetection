/********************************************************************************
** Form generated from reading UI file 'testqt.ui'
**
** Created by: Qt User Interface Compiler version 5.6.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TESTQT_H
#define UI_TESTQT_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGraphicsView>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_testQTClass
{
public:
    QWidget *centralWidget;
    QTabWidget *tabWidget;
    QWidget *filters;
    QGraphicsView *gvFS;
    QPushButton *loadImgFltr;
    QComboBox *filterTypeFltr;
    QLabel *label;
    QLabel *label_2;
    QSlider *filterSizeFltr;
    QPushButton *applyFltr;
    QPushButton *undoFltr;
    QLabel *label_9;
    QLabel *label_20;
    QLabel *label_32;
    QWidget *generation;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QSlider *fpsVG;
    QSlider *durationVG;
    QSlider *mxvVG;
    QSlider *myvVG;
    QSlider *npVG;
    QSlider *frVG;
    QLabel *label_8;
    QPushButton *generateVG;
    QLabel *label_10;
    QLabel *label_11;
    QLabel *label_12;
    QLabel *label_13;
    QLabel *label_14;
    QLabel *label_15;
    QSlider *nbrObjVG;
    QLabel *label_16;
    QLabel *label_17;
    QSlider *nrrVG;
    QLabel *label_18;
    QLabel *label_19;
    QLabel *label_21;
    QLabel *label_22;
    QSlider *noiseTypeVG;
    QLabel *label_23;
    QLabel *label_24;
    QLabel *label_25;
    QLabel *label_26;
    QLabel *label_27;
    QLabel *label_28;
    QLabel *label_29;
    QLabel *label_30;
    QLabel *label_31;
    QWidget *detection;
    QPushButton *loadVidVG;
    QPushButton *detectObjOD;

    void setupUi(QMainWindow *testQTClass)
    {
        if (testQTClass->objectName().isEmpty())
            testQTClass->setObjectName(QStringLiteral("testQTClass"));
        testQTClass->resize(1151, 679);
        centralWidget = new QWidget(testQTClass);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        tabWidget = new QTabWidget(centralWidget);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tabWidget->setGeometry(QRect(0, 0, 1151, 682));
        QFont font;
        font.setPointSize(10);
        tabWidget->setFont(font);
        filters = new QWidget();
        filters->setObjectName(QStringLiteral("filters"));
        gvFS = new QGraphicsView(filters);
        gvFS->setObjectName(QStringLiteral("gvFS"));
        gvFS->setGeometry(QRect(620, 70, 480, 480));
        loadImgFltr = new QPushButton(filters);
        loadImgFltr->setObjectName(QStringLiteral("loadImgFltr"));
        loadImgFltr->setGeometry(QRect(210, 160, 100, 40));
        QFont font1;
        font1.setPointSize(8);
        loadImgFltr->setFont(font1);
        filterTypeFltr = new QComboBox(filters);
        filterTypeFltr->setObjectName(QStringLiteral("filterTypeFltr"));
        filterTypeFltr->setGeometry(QRect(210, 240, 100, 40));
        filterTypeFltr->setFont(font1);
        label = new QLabel(filters);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(50, 240, 100, 40));
        label->setFont(font);
        label_2 = new QLabel(filters);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(50, 320, 145, 40));
        label_2->setFont(font);
        filterSizeFltr = new QSlider(filters);
        filterSizeFltr->setObjectName(QStringLiteral("filterSizeFltr"));
        filterSizeFltr->setGeometry(QRect(270, 320, 160, 40));
        filterSizeFltr->setMinimum(3);
        filterSizeFltr->setMaximum(11);
        filterSizeFltr->setSingleStep(2);
        filterSizeFltr->setPageStep(4);
        filterSizeFltr->setOrientation(Qt::Horizontal);
        filterSizeFltr->setTickPosition(QSlider::TicksBelow);
        filterSizeFltr->setTickInterval(2);
        applyFltr = new QPushButton(filters);
        applyFltr->setObjectName(QStringLiteral("applyFltr"));
        applyFltr->setGeometry(QRect(210, 400, 100, 40));
        applyFltr->setFont(font1);
        undoFltr = new QPushButton(filters);
        undoFltr->setObjectName(QStringLiteral("undoFltr"));
        undoFltr->setGeometry(QRect(390, 400, 100, 40));
        undoFltr->setFont(font1);
        label_9 = new QLabel(filters);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setGeometry(QRect(460, 330, 51, 16));
        label_20 = new QLabel(filters);
        label_20->setObjectName(QStringLiteral("label_20"));
        label_20->setGeometry(QRect(620, 70, 480, 480));
        label_32 = new QLabel(filters);
        label_32->setObjectName(QStringLiteral("label_32"));
        label_32->setGeometry(QRect(210, 330, 31, 16));
        tabWidget->addTab(filters, QString());
        generation = new QWidget();
        generation->setObjectName(QStringLiteral("generation"));
        label_3 = new QLabel(generation);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(240, 30, 100, 30));
        label_3->setFont(font);
        label_4 = new QLabel(generation);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(240, 130, 171, 30));
        label_5 = new QLabel(generation);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(240, 230, 150, 30));
        label_6 = new QLabel(generation);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(240, 280, 150, 30));
        label_7 = new QLabel(generation);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(240, 330, 150, 30));
        fpsVG = new QSlider(generation);
        fpsVG->setObjectName(QStringLiteral("fpsVG"));
        fpsVG->setGeometry(QRect(640, 30, 160, 30));
        fpsVG->setMinimum(10);
        fpsVG->setMaximum(144);
        fpsVG->setPageStep(30);
        fpsVG->setValue(30);
        fpsVG->setOrientation(Qt::Horizontal);
        fpsVG->setInvertedAppearance(false);
        fpsVG->setTickPosition(QSlider::TicksBelow);
        fpsVG->setTickInterval(10);
        durationVG = new QSlider(generation);
        durationVG->setObjectName(QStringLiteral("durationVG"));
        durationVG->setGeometry(QRect(640, 130, 160, 30));
        durationVG->setMinimum(10);
        durationVG->setMaximum(60);
        durationVG->setValue(15);
        durationVG->setOrientation(Qt::Horizontal);
        durationVG->setTickPosition(QSlider::TicksBelow);
        durationVG->setTickInterval(10);
        mxvVG = new QSlider(generation);
        mxvVG->setObjectName(QStringLiteral("mxvVG"));
        mxvVG->setGeometry(QRect(640, 230, 160, 30));
        mxvVG->setMinimum(2);
        mxvVG->setMaximum(8);
        mxvVG->setSingleStep(1);
        mxvVG->setPageStep(2);
        mxvVG->setValue(3);
        mxvVG->setSliderPosition(3);
        mxvVG->setTracking(true);
        mxvVG->setOrientation(Qt::Horizontal);
        mxvVG->setTickPosition(QSlider::TicksBelow);
        mxvVG->setTickInterval(1);
        myvVG = new QSlider(generation);
        myvVG->setObjectName(QStringLiteral("myvVG"));
        myvVG->setGeometry(QRect(640, 280, 160, 30));
        myvVG->setMinimum(2);
        myvVG->setMaximum(8);
        myvVG->setSingleStep(1);
        myvVG->setPageStep(2);
        myvVG->setValue(3);
        myvVG->setOrientation(Qt::Horizontal);
        myvVG->setTickPosition(QSlider::TicksBelow);
        myvVG->setTickInterval(1);
        npVG = new QSlider(generation);
        npVG->setObjectName(QStringLiteral("npVG"));
        npVG->setGeometry(QRect(640, 330, 160, 30));
        npVG->setMinimum(1);
        npVG->setMaximum(50);
        npVG->setPageStep(5);
        npVG->setValue(10);
        npVG->setOrientation(Qt::Horizontal);
        npVG->setTickPosition(QSlider::TicksBelow);
        npVG->setTickInterval(5);
        frVG = new QSlider(generation);
        frVG->setObjectName(QStringLiteral("frVG"));
        frVG->setGeometry(QRect(640, 80, 160, 30));
        frVG->setMinimum(480);
        frVG->setMaximum(1080);
        frVG->setPageStep(100);
        frVG->setValue(720);
        frVG->setOrientation(Qt::Horizontal);
        frVG->setTickPosition(QSlider::TicksBelow);
        frVG->setTickInterval(100);
        label_8 = new QLabel(generation);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(240, 80, 150, 30));
        generateVG = new QPushButton(generation);
        generateVG->setObjectName(QStringLiteral("generateVG"));
        generateVG->setGeometry(QRect(240, 590, 100, 30));
        label_10 = new QLabel(generation);
        label_10->setObjectName(QStringLiteral("label_10"));
        label_10->setGeometry(QRect(820, 30, 55, 16));
        label_11 = new QLabel(generation);
        label_11->setObjectName(QStringLiteral("label_11"));
        label_11->setGeometry(QRect(820, 80, 55, 16));
        label_12 = new QLabel(generation);
        label_12->setObjectName(QStringLiteral("label_12"));
        label_12->setGeometry(QRect(820, 130, 55, 16));
        label_13 = new QLabel(generation);
        label_13->setObjectName(QStringLiteral("label_13"));
        label_13->setGeometry(QRect(820, 230, 55, 16));
        label_14 = new QLabel(generation);
        label_14->setObjectName(QStringLiteral("label_14"));
        label_14->setGeometry(QRect(820, 280, 55, 16));
        label_15 = new QLabel(generation);
        label_15->setObjectName(QStringLiteral("label_15"));
        label_15->setGeometry(QRect(820, 330, 55, 16));
        nbrObjVG = new QSlider(generation);
        nbrObjVG->setObjectName(QStringLiteral("nbrObjVG"));
        nbrObjVG->setGeometry(QRect(640, 180, 160, 30));
        nbrObjVG->setMinimum(1);
        nbrObjVG->setMaximum(8);
        nbrObjVG->setPageStep(2);
        nbrObjVG->setValue(8);
        nbrObjVG->setOrientation(Qt::Horizontal);
        nbrObjVG->setTickPosition(QSlider::TicksBelow);
        nbrObjVG->setTickInterval(1);
        label_16 = new QLabel(generation);
        label_16->setObjectName(QStringLiteral("label_16"));
        label_16->setGeometry(QRect(240, 180, 150, 30));
        label_17 = new QLabel(generation);
        label_17->setObjectName(QStringLiteral("label_17"));
        label_17->setGeometry(QRect(820, 180, 55, 16));
        nrrVG = new QSlider(generation);
        nrrVG->setObjectName(QStringLiteral("nrrVG"));
        nrrVG->setGeometry(QRect(640, 380, 160, 30));
        nrrVG->setMinimum(5);
        nrrVG->setMaximum(60);
        nrrVG->setSingleStep(2);
        nrrVG->setPageStep(5);
        nrrVG->setValue(15);
        nrrVG->setOrientation(Qt::Horizontal);
        nrrVG->setTickPosition(QSlider::TicksBelow);
        nrrVG->setTickInterval(5);
        label_18 = new QLabel(generation);
        label_18->setObjectName(QStringLiteral("label_18"));
        label_18->setGeometry(QRect(820, 380, 55, 16));
        label_19 = new QLabel(generation);
        label_19->setObjectName(QStringLiteral("label_19"));
        label_19->setGeometry(QRect(240, 380, 231, 30));
        label_21 = new QLabel(generation);
        label_21->setObjectName(QStringLiteral("label_21"));
        label_21->setGeometry(QRect(240, 430, 231, 30));
        label_22 = new QLabel(generation);
        label_22->setObjectName(QStringLiteral("label_22"));
        label_22->setGeometry(QRect(820, 430, 55, 16));
        noiseTypeVG = new QSlider(generation);
        noiseTypeVG->setObjectName(QStringLiteral("noiseTypeVG"));
        noiseTypeVG->setGeometry(QRect(640, 430, 160, 30));
        noiseTypeVG->setMinimum(0);
        noiseTypeVG->setMaximum(1);
        noiseTypeVG->setSingleStep(1);
        noiseTypeVG->setPageStep(1);
        noiseTypeVG->setValue(1);
        noiseTypeVG->setOrientation(Qt::Horizontal);
        noiseTypeVG->setTickPosition(QSlider::TicksBelow);
        noiseTypeVG->setTickInterval(1);
        label_23 = new QLabel(generation);
        label_23->setObjectName(QStringLiteral("label_23"));
        label_23->setGeometry(QRect(580, 30, 55, 16));
        label_24 = new QLabel(generation);
        label_24->setObjectName(QStringLiteral("label_24"));
        label_24->setGeometry(QRect(580, 180, 55, 16));
        label_25 = new QLabel(generation);
        label_25->setObjectName(QStringLiteral("label_25"));
        label_25->setGeometry(QRect(580, 330, 55, 16));
        label_26 = new QLabel(generation);
        label_26->setObjectName(QStringLiteral("label_26"));
        label_26->setGeometry(QRect(580, 130, 55, 16));
        label_27 = new QLabel(generation);
        label_27->setObjectName(QStringLiteral("label_27"));
        label_27->setGeometry(QRect(580, 80, 55, 16));
        label_28 = new QLabel(generation);
        label_28->setObjectName(QStringLiteral("label_28"));
        label_28->setGeometry(QRect(580, 280, 55, 16));
        label_29 = new QLabel(generation);
        label_29->setObjectName(QStringLiteral("label_29"));
        label_29->setGeometry(QRect(580, 430, 55, 16));
        label_30 = new QLabel(generation);
        label_30->setObjectName(QStringLiteral("label_30"));
        label_30->setGeometry(QRect(580, 230, 55, 16));
        label_31 = new QLabel(generation);
        label_31->setObjectName(QStringLiteral("label_31"));
        label_31->setGeometry(QRect(580, 380, 55, 16));
        tabWidget->addTab(generation, QString());
        detection = new QWidget();
        detection->setObjectName(QStringLiteral("detection"));
        loadVidVG = new QPushButton(detection);
        loadVidVG->setObjectName(QStringLiteral("loadVidVG"));
        loadVidVG->setGeometry(QRect(490, 220, 100, 40));
        loadVidVG->setFont(font1);
        detectObjOD = new QPushButton(detection);
        detectObjOD->setObjectName(QStringLiteral("detectObjOD"));
        detectObjOD->setGeometry(QRect(490, 280, 100, 40));
        detectObjOD->setFont(font1);
        tabWidget->addTab(detection, QString());
        testQTClass->setCentralWidget(centralWidget);

        retranslateUi(testQTClass);

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(testQTClass);
    } // setupUi

    void retranslateUi(QMainWindow *testQTClass)
    {
        testQTClass->setWindowTitle(QApplication::translate("testQTClass", "Cosmic Objects Detector", Q_NULLPTR));
        loadImgFltr->setText(QApplication::translate("testQTClass", "Load an image", Q_NULLPTR));
        filterTypeFltr->clear();
        filterTypeFltr->insertItems(0, QStringList()
         << QApplication::translate("testQTClass", "Mean", Q_NULLPTR)
         << QApplication::translate("testQTClass", "Median", Q_NULLPTR)
         << QApplication::translate("testQTClass", "Gaussian", Q_NULLPTR)
         << QApplication::translate("testQTClass", "Gradient_X", Q_NULLPTR)
         << QApplication::translate("testQTClass", "Gradient_Y", Q_NULLPTR)
         << QApplication::translate("testQTClass", "Laplacian", Q_NULLPTR)
         << QApplication::translate("testQTClass", "Erosian", Q_NULLPTR)
         << QApplication::translate("testQTClass", "Dilatation", Q_NULLPTR)
        );
        label->setText(QApplication::translate("testQTClass", "Select filter", Q_NULLPTR));
        label_2->setText(QApplication::translate("testQTClass", "Select kernel size", Q_NULLPTR));
        applyFltr->setText(QApplication::translate("testQTClass", "Apply", Q_NULLPTR));
        undoFltr->setText(QApplication::translate("testQTClass", "Undo", Q_NULLPTR));
        label_9->setText(QApplication::translate("testQTClass", "11x11", Q_NULLPTR));
        label_20->setText(QApplication::translate("testQTClass", "         Load an image to see it here.", Q_NULLPTR));
        label_32->setText(QApplication::translate("testQTClass", "3x3", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(filters), QApplication::translate("testQTClass", "Filters Studio", Q_NULLPTR));
        label_3->setText(QApplication::translate("testQTClass", "FPS:", Q_NULLPTR));
        label_4->setText(QApplication::translate("testQTClass", "Duration (in seconds):", Q_NULLPTR));
        label_5->setText(QApplication::translate("testQTClass", "Mean X velocity:", Q_NULLPTR));
        label_6->setText(QApplication::translate("testQTClass", "Mean Y velocity:", Q_NULLPTR));
        label_7->setText(QApplication::translate("testQTClass", "Noise points:", Q_NULLPTR));
        label_8->setText(QApplication::translate("testQTClass", "Frame resolution:", Q_NULLPTR));
        generateVG->setText(QApplication::translate("testQTClass", "Generate", Q_NULLPTR));
        label_10->setText(QApplication::translate("testQTClass", "144", Q_NULLPTR));
        label_11->setText(QApplication::translate("testQTClass", "1080", Q_NULLPTR));
        label_12->setText(QApplication::translate("testQTClass", "60", Q_NULLPTR));
        label_13->setText(QApplication::translate("testQTClass", "8", Q_NULLPTR));
        label_14->setText(QApplication::translate("testQTClass", "8", Q_NULLPTR));
        label_15->setText(QApplication::translate("testQTClass", "50", Q_NULLPTR));
        label_16->setText(QApplication::translate("testQTClass", "Number of objects:", Q_NULLPTR));
        label_17->setText(QApplication::translate("testQTClass", "8", Q_NULLPTR));
        label_18->setText(QApplication::translate("testQTClass", "60", Q_NULLPTR));
        label_19->setText(QApplication::translate("testQTClass", "Noise refresh rate (frames):", Q_NULLPTR));
        label_21->setText(QApplication::translate("testQTClass", "Noise typ (Points|Objects):", Q_NULLPTR));
        label_22->setText(QApplication::translate("testQTClass", "1", Q_NULLPTR));
        label_23->setText(QApplication::translate("testQTClass", "10", Q_NULLPTR));
        label_24->setText(QApplication::translate("testQTClass", "1", Q_NULLPTR));
        label_25->setText(QApplication::translate("testQTClass", "1", Q_NULLPTR));
        label_26->setText(QApplication::translate("testQTClass", "10", Q_NULLPTR));
        label_27->setText(QApplication::translate("testQTClass", "480", Q_NULLPTR));
        label_28->setText(QApplication::translate("testQTClass", "2", Q_NULLPTR));
        label_29->setText(QApplication::translate("testQTClass", "0", Q_NULLPTR));
        label_30->setText(QApplication::translate("testQTClass", "2", Q_NULLPTR));
        label_31->setText(QApplication::translate("testQTClass", "5", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(generation), QApplication::translate("testQTClass", "Video Generation", Q_NULLPTR));
        loadVidVG->setText(QApplication::translate("testQTClass", "Load a video", Q_NULLPTR));
        detectObjOD->setText(QApplication::translate("testQTClass", "Detect Objects", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(detection), QApplication::translate("testQTClass", "Object Detection", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class testQTClass: public Ui_testQTClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TESTQT_H
