#ifndef TESTQT_H
#define TESTQT_H

#include <QtWidgets/QMainWindow>
#include "ui_testqt.h"

class testQT : public QMainWindow
{
	Q_OBJECT

public:
	testQT(QWidget *parent = 0);
	~testQT();

private:
	Ui::testQTClass ui;
	private slots:
	void fltrLoadImg();
	void applyFltr();
	void updateLabelFltr();
	void generateVideo();
	void loadVid();
	void detectObj();
};

#endif // TESTQT_H
