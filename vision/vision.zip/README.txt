Travail réalisé par:
	AOUF Ali
	BOUNOUH Nesrine
	TATACHAK Fz Amina
	Hariti Halima

Description des fichiers joints:
	assets: Contenant 
		* la vidéo générée sous forme de RGBA.
		* les images utilisés pour verifier le bon fonctionnement des filtres
	
	Source Code: Contenant la totalite du code avec QT.
	testQT.exe: l'executable généré avec QT.
	Rapport-Projet-Vision-FINAL.pdf: contenant le rapport du projet
	
	